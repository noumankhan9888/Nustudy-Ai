CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`question` text NOT NULL,
	`answer` text NOT NULL,
	`sourcesJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documentChunks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`documentId` int NOT NULL,
	`userId` int NOT NULL,
	`pageNumber` int NOT NULL,
	`chunkNumber` int NOT NULL,
	`content` text NOT NULL,
	`embeddingJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `documentChunks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`storageUrl` varchar(768) NOT NULL,
	`mimeType` varchar(128) NOT NULL,
	`fileSize` int NOT NULL,
	`pageCount` int NOT NULL DEFAULT 0,
	`chunkCount` int NOT NULL DEFAULT 0,
	`status` enum('uploaded','processing','ready','failed') NOT NULL DEFAULT 'uploaded',
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quizAttempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`quizId` int NOT NULL,
	`score` int NOT NULL,
	`totalQuestions` int NOT NULL,
	`percentage` int NOT NULL,
	`answersJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quizAttempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quizzes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`documentId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`difficulty` enum('easy','medium','hard') NOT NULL,
	`questionCount` int NOT NULL,
	`questionsJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quizzes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studyNotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`documentId` int NOT NULL,
	`kind` enum('summary','key_concepts') NOT NULL,
	`detail` varchar(32) NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `studyNotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `chat_messages_user_created_idx` ON `chatMessages` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `chunks_user_document_idx` ON `documentChunks` (`userId`,`documentId`);--> statement-breakpoint
CREATE INDEX `chunks_document_page_idx` ON `documentChunks` (`documentId`,`pageNumber`);--> statement-breakpoint
CREATE INDEX `documents_user_created_idx` ON `documents` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `quiz_attempts_user_created_idx` ON `quizAttempts` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `quizzes_user_created_idx` ON `quizzes` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `study_notes_user_document_idx` ON `studyNotes` (`userId`,`documentId`);