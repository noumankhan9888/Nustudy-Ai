import { index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Metadata and processing state for a user-owned PDF stored in object storage. */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  storageUrl: varchar("storageUrl", { length: 768 }).notNull(),
  mimeType: varchar("mimeType", { length: 128 }).notNull(),
  fileSize: int("fileSize").notNull(),
  pageCount: int("pageCount").default(0).notNull(),
  chunkCount: int("chunkCount").default(0).notNull(),
  status: mysqlEnum("status", ["uploaded", "processing", "ready", "failed"]).default("uploaded").notNull(),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("documents_user_created_idx").on(table.userId, table.createdAt)]);

/** Page-aware retrieval records. Embedding vectors are serialized JSON for a compact, explainable student-scale index. */
export const documentChunks = mysqlTable("documentChunks", {
  id: int("id").autoincrement().primaryKey(),
  documentId: int("documentId").notNull(),
  userId: int("userId").notNull(),
  pageNumber: int("pageNumber").notNull(),
  chunkNumber: int("chunkNumber").notNull(),
  content: text("content").notNull(),
  embeddingJson: text("embeddingJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("chunks_user_document_idx").on(table.userId, table.documentId),
  index("chunks_document_page_idx").on(table.documentId, table.pageNumber),
]);

/** Session-scoped question and answer history, including its retrieved citations. */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  sourcesJson: text("sourcesJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("chat_messages_user_created_idx").on(table.userId, table.createdAt)]);

/** Saved summary or key-concept notes generated from a selected user document. */
export const studyNotes = mysqlTable("studyNotes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  documentId: int("documentId").notNull(),
  kind: mysqlEnum("kind", ["summary", "key_concepts"]).notNull(),
  detail: varchar("detail", { length: 32 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("study_notes_user_document_idx").on(table.userId, table.documentId)]);

/** A generated question set, stored as structured JSON to keep quiz generation and delivery simple. */
export const quizzes = mysqlTable("quizzes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  documentId: int("documentId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).notNull(),
  questionCount: int("questionCount").notNull(),
  questionsJson: text("questionsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("quizzes_user_created_idx").on(table.userId, table.createdAt)]);

/** A scored submission against a generated quiz, retained for the personal progress dashboard. */
export const quizAttempts = mysqlTable("quizAttempts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  quizId: int("quizId").notNull(),
  score: int("score").notNull(),
  totalQuestions: int("totalQuestions").notNull(),
  percentage: int("percentage").notNull(),
  answersJson: text("answersJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("quiz_attempts_user_created_idx").on(table.userId, table.createdAt)]);

export type Document = typeof documents.$inferSelect;
export type DocumentChunk = typeof documentChunks.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type StudyNote = typeof studyNotes.$inferSelect;
export type Quiz = typeof quizzes.$inferSelect;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
