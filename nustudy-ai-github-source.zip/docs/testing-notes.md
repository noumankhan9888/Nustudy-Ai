# Testing Notes

The browser review confirmed that the preview shows the authenticated sign-in screen when no session cookie is present, and that the protected routes expose the Library, Ask, Summaries, Quizzes, and Progress workspaces after sign-in. The end-to-end content test uses the public 15-page **Database Normalisation** lecture PDF at <https://lse-me314.github.io/other_resources/database_normalisation_notes.pdf>. The PDF was visually verified as educational lecture material and is used to exercise page extraction, local vector retrieval, grounded answer generation, summary generation, and MCQ generation.

## Final QA Pass — Nustudy AI

The final quality pass exercised a real two-document workflow using the Database Normalisation PDF above and the public 24-page [Introduction to Computer Networks PDF](https://python4csip.com/files/download/Introduction%20to%20computer%20Networks.pdf). The regression test uploads both documents through the real server procedure, verifies that each is processed and page-indexed, queries each selected source independently, checks cited answers contain the selected document ID, generates a summary, creates a five-question quiz, submits the stored correct answer key for a verified 100% score, and deletes both test sources.

The pass also validates safe error behavior. A PowerPoint upload is rejected with “Only PDF files can be uploaded”; a fake `.pdf` with non-PDF bytes is rejected as invalid; a minimal unreadable PDF returns a concise text-based-PDF message; and a missing AI-service configuration returns a clear owner-configuration message instead of an internal credential error. Desktop and mobile previews were reviewed for the Nustudy AI navigation, spacing, dashboard cards, chat workspace, footer, and empty/loading states.
