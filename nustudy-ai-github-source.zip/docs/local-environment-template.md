# Local Environment Template

The managed project injects its credentials at runtime and deliberately does not store a `.env` or `.env.example` file. For a standalone local clone, create a private `.env` from the following safe template and replace every placeholder before running the app.

```dotenv
# MySQL or TiDB database
DATABASE_URL=mysql://USER:PASSWORD@HOST:3306/ai_studymate

# Authentication
JWT_SECRET=replace-with-a-long-random-string
VITE_APP_ID=your-oauth-app-id
VITE_OAUTH_PORTAL_URL=https://your-oauth-portal.example
OAUTH_SERVER_URL=https://your-oauth-server.example

# Server-only built-in LLM and storage proxy credentials
BUILT_IN_FORGE_API_URL=https://your-llm-and-storage-proxy.example
BUILT_IN_FORGE_API_KEY=replace-with-server-only-key
```

Keep this `.env` file private. The repository’s `.gitignore` already excludes it.
