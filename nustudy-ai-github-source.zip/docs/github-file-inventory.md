# Nustudy AI GitHub File Inventory

Upload the repository contents from the project root after checking `git status`. The following source files and folders are part of the working application.

| Path | Purpose | Upload to GitHub? |
| --- | --- | --- |
| `client/` | React frontend, pages, layout, styling, and UI components | Yes |
| `server/` | Express/tRPC server, authentication integration, PDF/RAG/AI services, database helpers, and tests | Yes |
| `shared/` | Shared types and constants | Yes |
| `drizzle/` | Database schema, relations, and migrations | Yes |
| `.github/workflows/quality.yml` | TypeScript and production-build checks on GitHub | Yes |
| `docs/` | Environment reference, testing notes, GitHub/LinkedIn kit, and this inventory | Yes |
| `README.md` | Project overview, architecture, setup, testing, GitHub upload, and deployment guide | Yes |
| `LICENSE` | MIT open-source license | Yes |
| `package.json` | Scripts and dependencies | Yes |
| `pnpm-lock.yaml` | Reproducible dependency lockfile | Yes |
| `tsconfig.json`, `vite.config.ts`, `vitest.config.ts` | TypeScript, frontend, and test configuration | Yes |
| `drizzle.config.ts`, `components.json`, `template.json` | Database, UI, and project configuration | Yes |
| `.gitignore`, `.prettierignore`, `.prettierrc` | Repository hygiene and formatting rules | Yes |
| `patches/` | Required package patch files | Yes |
| `.env` and other environment files | Private local credentials | **No** |
| `node_modules/` | Installed dependencies | **No** |
| `dist/` | Generated production output | **No** |
| `.manus-logs/` and `.project-config.json` | Managed-environment artifacts | **No** |

The safest upload sequence is `git add .`, followed by `git status` and `git diff --cached --stat`. Do not push until the staged list contains no secrets, environment files, database exports, or generated dependency/build folders.
