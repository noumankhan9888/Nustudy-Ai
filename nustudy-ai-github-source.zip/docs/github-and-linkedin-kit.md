# Nustudy AI — GitHub and LinkedIn Kit

This document packages the public-facing information for the **Nustudy AI** university AI portfolio project.

## GitHub Upload Checklist

Create an empty GitHub repository named `nustudy-ai` without generating another README, license, or `.gitignore`. From the project root, run:

```html
git init
git add .
git status
git diff --cached --stat
git commit -m "Prepare Nustudy AI for GitHub"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nustudy-ai.git
git push -u origin main
```

Before pushing, confirm that no `.env`, credentials, database dump, `dist/`, or `node_modules/` appears in the staged files. The repository already includes `.gitignore`, `LICENSE`, `README.md`, `package.json`, `pnpm-lock.yaml`, database migrations, tests, setup documentation, and a GitHub Actions workflow.

## LinkedIn Project Title

**Nustudy AI — AI-Powered Study Assistant**

## LinkedIn Short Description

Nustudy AI is a full-stack RAG application that transforms uploaded study PDFs into searchable, citation-grounded learning material. Students can ask questions with page references, generate summaries and key concepts, create MCQ quizzes, receive scores and explanations, and track their study progress in one responsive workspace.

## LinkedIn Project Bio

I built **Nustudy AI**, an AI-powered study companion designed to help students learn from their own lecture notes and educational PDFs. The project uses a clear retrieval-augmented generation pipeline: **PDF upload → page-aware text extraction → chunking → vector embeddings → similarity search → retrieved context → grounded LLM answer**.

The application supports private document libraries, source/page citations, document summaries, key-concept notes, source-based MCQ generation, interactive quizzes, deterministic scoring, and saved progress history. It was built as a practical university-level AI engineering project with a React and TypeScript frontend, Express and tRPC backend, Drizzle ORM, MySQL/TiDB persistence, S3-compatible file storage, and server-side LLM integration.

A major design goal was explainability. The assistant is instructed to answer only from retrieved uploaded content and to clearly say when the information cannot be found in the documents. The project was tested with real educational PDFs, multi-document retrieval, invalid and corrupted file paths, citation behavior, quiz scoring, document deletion, responsive layouts, automated tests, and a production build.

## LinkedIn Post Caption

I’m excited to share **Nustudy AI — AI-Powered Study Assistant**, a full-stack RAG project built for smarter, more explainable learning.

Instead of asking an LLM to guess from general knowledge, Nustudy AI retrieves relevant passages from a student’s uploaded PDFs and connects each answer to its source document and page. The same material can then be converted into summaries, key-concept notes, MCQs, interactive quizzes, scores, and progress history.

The core pipeline is:

> PDF → Text Extraction → Chunking → Embeddings → Vector Search → Retrieved Context → LLM → Answer + Sources

This project helped me practice applied AI engineering, backend development, database design, prompt grounding, user experience design, testing, and deployment readiness.

#ArtificialIntelligence #RAG #LLM #GenerativeAI #TypeScript #React #AIEngineering #StudentProject #EdTech

## Suggested Screenshot Order

| Order | File | LinkedIn caption cue |
| --- | --- | --- |
| 1 | `01-nustudy-ai-dashboard.png` | A focused dashboard for documents, questions, quizzes, and scores. |
| 2 | `02-nustudy-ai-library.png` | Upload and manage private study sources. |
| 3 | `03-nustudy-ai-grounded-chat.png` | Ask questions and keep answers tied to uploaded sources. |
| 4 | `04-nustudy-ai-revision-notes.png` | Turn a processed document into structured revision notes. |
| 5 | `05-nustudy-ai-quiz-generator.png` | Generate source-based MCQs with selectable difficulty. |
| 6 | `06-nustudy-ai-progress.png` | Track quiz averages, best scores, and saved attempts. |

## Project Facts for a Portfolio

| Area | Implemented capability |
| --- | --- |
| RAG | Page-aware chunking, compact embeddings, cosine similarity, retrieved context, grounded generation |
| Document AI | PDF validation, extraction, processing states, source/page references, deletion cleanup |
| Study generation | Summaries, key concepts, structured MCQs, explanations |
| Assessment | Interactive answer selection, deterministic scoring, saved quiz attempts |
| Security | Authenticated access, user-owned records, server-side AI and storage credentials |
| Quality | TypeScript validation, automated tests, real educational-PDF workflows, production build |
| Deployment | Node.js application with MySQL/TiDB, OAuth, S3-compatible storage, and server-side LLM configuration |

## Screenshot Assets

The six PNG screenshots are delivered with the project handoff as separate files. For a repository copy, place them in `docs/screenshots/` and update README image paths to relative paths such as `docs/screenshots/01-nustudy-ai-dashboard.png`. The managed project also has public preview paths in the README for online viewing.

