import { afterEach, describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

const NORMALISATION_PDF = "https://lse-me314.github.io/other_resources/database_normalisation_notes.pdf";
const NETWORKS_PDF = "https://python4csip.com/files/download/Introduction%20to%20computer%20Networks.pdf";
const userId = 1_800_000_000 + Math.floor(Math.random() * 10_000_000);
const documentIds: number[] = [];

function context(): TrpcContext {
  return {
    user: { id: userId, openId: `workflow-${userId}`, name: "Workflow QA", email: null, loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

async function getBase64(url: string) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Could not download test PDF (${response.status}).`);
  return Buffer.from(await response.arrayBuffer()).toString("base64");
}

afterEach(async () => {
  const ownedDocuments = await db.listDocuments(userId).catch(() => []);
  await Promise.all(ownedDocuments.map(document => db.deleteDocumentForUser(document.id, userId).catch(() => undefined)));
  documentIds.splice(0);
});

describe("real multi-document study workflow", () => {
  it("uploads two educational PDFs, retrieves selected sources, generates study material, scores a quiz, and deletes sources", async () => {
    const caller = appRouter.createCaller(context());
    const [normalisationBase64, networksBase64] = await Promise.all([getBase64(NORMALISATION_PDF), getBase64(NETWORKS_PDF)]);

    const normalisation = await caller.documents.upload({ fileName: "Database Normalisation.pdf", mimeType: "application/pdf", base64: normalisationBase64 });
    const networks = await caller.documents.upload({ fileName: "Introduction to Computer Networks.pdf", mimeType: "application/pdf", base64: networksBase64 });
    documentIds.push(normalisation.id, networks.id);
    expect(normalisation).toMatchObject({ status: "ready" });
    expect(networks).toMatchObject({ status: "ready" });
    expect(normalisation.pageCount).toBeGreaterThan(10);
    expect(networks.pageCount).toBeGreaterThan(10);

    const normalisationSearch = await caller.documents.search({ query: "What does normalisation eliminate?", documentIds: [normalisation.id] });
    const networkSearch = await caller.documents.search({ query: "What is a computer network?", documentIds: [networks.id] });
    expect(normalisationSearch.length).toBeGreaterThan(0);
    expect(normalisationSearch.every(result => result.documentId === normalisation.id && result.pageNumber > 0)).toBe(true);
    expect(networkSearch.length).toBeGreaterThan(0);
    expect(networkSearch.every(result => result.documentId === networks.id && result.pageNumber > 0)).toBe(true);

    const answer = await caller.chat.ask({ question: "What does normalisation eliminate?", documentIds: [normalisation.id] });
    expect(answer.answer.length).toBeGreaterThan(30);
    expect(answer.sources.length).toBeGreaterThan(0);
    expect(answer.sources.every(source => source.documentId === normalisation.id && source.pageNumber > 0 && source.storageUrl.includes("/manus-storage/"))).toBe(true);
    const networkAnswer = await caller.chat.ask({ question: "What is a computer network?", documentIds: [networks.id] });
    expect(networkAnswer.answer.length).toBeGreaterThan(30);
    expect(networkAnswer.sources.length).toBeGreaterThan(0);
    expect(networkAnswer.sources.every(source => source.documentId === networks.id && source.pageNumber > 0)).toBe(true);
    const noAnswer = await caller.chat.ask({ question: "How does photosynthesis make glucose?", documentIds: [normalisation.id] });
    expect(noAnswer).toEqual({ answer: "I couldn't find this information in the uploaded documents.", sources: [] });

    const summary = await caller.notes.generate({ documentId: normalisation.id, kind: "summary", detail: "short" });
    expect(summary.content.length).toBeGreaterThan(30);
    const quiz = await caller.quizzes.generate({ documentId: networks.id, difficulty: "easy", count: 5 });
    const quizDetail = await caller.quizzes.get({ quizId: quiz.quizId });
    expect(quizDetail.questions).toHaveLength(5);
    expect(quizDetail.questions.every(question => question.options.length === 4)).toBe(true);
    const storedQuiz = await db.getQuizForUser(quiz.quizId, userId);
    const answerKey = JSON.parse(storedQuiz!.quiz.questionsJson) as Array<{ correctIndex: number }>;
    const score = await caller.quizzes.submit({ quizId: quiz.quizId, answers: answerKey.map(question => question.correctIndex) });
    expect(score.totalQuestions).toBe(5);
    expect(score.score).toBe(5);
    expect(score.percentage).toBe(100);

    await expect(caller.documents.upload({ fileName: "lecture.pptx", mimeType: "application/vnd.openxmlformats-officedocument.presentationml.presentation", base64: networksBase64 })).rejects.toMatchObject({ message: "Only PDF files can be uploaded." });
    await expect(caller.documents.upload({ fileName: "corrupted.pdf", mimeType: "application/pdf", base64: Buffer.from("This is not a PDF document.").toString("base64") })).rejects.toMatchObject({ message: "The uploaded file is not a valid PDF." });
    await expect(caller.documents.upload({ fileName: "empty.pdf", mimeType: "application/pdf", base64: Buffer.from("%PDF-1.4\n%%EOF\n").toString("base64") })).rejects.toMatchObject({ message: "We could not process this PDF. Please try another text-based PDF." });

    await expect(caller.documents.delete({ documentId: normalisation.id })).resolves.toEqual({ success: true });
    documentIds.splice(documentIds.indexOf(normalisation.id), 1);
    expect(await caller.documents.search({ query: "What does normalisation eliminate?", documentIds: [normalisation.id] })).toEqual([]);
    await expect(caller.documents.delete({ documentId: networks.id })).resolves.toEqual({ success: true });
    documentIds.splice(documentIds.indexOf(networks.id), 1);
  }, 180_000);
});
