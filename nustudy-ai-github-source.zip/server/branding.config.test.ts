import { describe, expect, it } from "vitest";

describe("Nustudy AI project configuration", () => {
  it("provides the configured website title to the server runtime", () => {
    expect(process.env.VITE_APP_TITLE).toBe("Nustudy AI");
  });
});
