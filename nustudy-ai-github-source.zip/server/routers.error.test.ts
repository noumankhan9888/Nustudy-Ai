import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn() }));

import { invokeLLM } from "./_core/llm";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

const userId = 1_850_000_000 + Math.floor(Math.random() * 10_000_000);
let documentId: number | undefined;

function createContext(): TrpcContext {
  return {
    user: { id: userId, openId: `qa-${userId}`, name: "QA user", email: null, loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

afterEach(async () => {
  vi.clearAllMocks();
  if (documentId) await db.deleteDocumentForUser(documentId, userId).catch(() => undefined);
  documentId = undefined;
});

describe("study-service error handling", () => {
  it("returns a clear user-facing message when the AI service is unavailable", async () => {
    documentId = await db.createDocument({ userId, fileName: "Reliable Systems.pdf", storageKey: "test/reliable.pdf", storageUrl: "/manus-storage/test/reliable.pdf", mimeType: "application/pdf", fileSize: 1024 });
    await db.insertDocumentChunks({ userId, documentId, chunks: [{ pageNumber: 1, chunkNumber: 1, content: "A reliable system is designed to continue operating correctly under expected conditions.", embedding: [0.3, 0.7] }] });
    await db.updateDocumentProcessing({ documentId, userId, status: "ready", pageCount: 1, chunkCount: 1 });
    vi.mocked(invokeLLM).mockRejectedValueOnce(new Error("OPENAI_API_KEY is not configured"));

    const caller = appRouter.createCaller(createContext());
    await expect(caller.chat.ask({ question: "What is a reliable system?", documentIds: [documentId] })).rejects.toMatchObject({ message: "The AI study service is not configured. Please ask the project owner to configure it, then try again." });
  });
});
