import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { extractPdfPages } from "./services/pdf";
import { chunkPages, cosineSimilarity, createEmbedding, hasMeaningfulQuestionOverlap, makeSnippet } from "./services/retrieval";
import { answerFromContext, generateQuestions, generateStudyNote, type Citation, type QuizQuestion } from "./services/studyAi";
import { gradeQuiz } from "./services/quiz";
import { storagePut } from "./storage";

const MAX_PDF_SIZE_BYTES = 20 * 1024 * 1024;

function safeDocumentName(value: string) {
  return value.replace(/[^a-zA-Z0-9._ -]/g, "_").slice(0, 180) || "study-document.pdf";
}

function appError(error: unknown, fallback: string): never {
  if (error instanceof TRPCError) throw error;
  const internalMessage = error instanceof Error ? error.message : "";
  if (/OPENAI_API_KEY|not configured|Storage config missing/i.test(internalMessage)) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "The AI study service is not configured. Please ask the project owner to configure it, then try again." });
  }
  console.error("[Study workflow error]", internalMessage || fallback);
  throw new TRPCError({ code: "BAD_REQUEST", message: fallback });
}

function rankChunks(rows: Awaited<ReturnType<typeof db.getChunksForSearch>>, question: string) {
  const questionEmbedding = createEmbedding(question);
  return rows
    .map(row => ({
      ...row,
      score: cosineSimilarity(questionEmbedding, JSON.parse(row.embeddingJson) as number[]),
    }))
    .filter(row => hasMeaningfulQuestionOverlap(question, row.content))
    .sort((left, right) => right.score - left.score)
    .slice(0, 5);
}

function buildContext(chunks: ReturnType<typeof rankChunks>) {
  return chunks.map((chunk, index) => `Source ${index + 1} — ${chunk.documentName}, page ${chunk.pageNumber}, chunk ${chunk.chunkNumber}:\n${chunk.content}`).join("\n\n");
}

function citationsFor(chunks: ReturnType<typeof rankChunks>): Citation[] {
  return chunks.map(chunk => ({
    documentId: chunk.documentId,
    documentName: chunk.documentName,
    pageNumber: chunk.pageNumber,
    chunkNumber: chunk.chunkNumber,
    storageUrl: chunk.storageUrl,
  }));
}

function publicQuiz(quiz: QuizQuestion[]) {
  return quiz.map(({ question, options }, index) => ({ id: index, question, options }));
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  documents: router({
    list: protectedProcedure.query(({ ctx }) => db.listDocuments(ctx.user.id)),
    upload: protectedProcedure.input(z.object({
      fileName: z.string().min(1).max(255),
      mimeType: z.string().max(128),
      base64: z.string().min(20).max(29_000_000),
    })).mutation(async ({ ctx, input }) => {
      let documentId: number | undefined;
      try {
        if (input.mimeType !== "application/pdf" || !input.fileName.toLowerCase().endsWith(".pdf")) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Only PDF files can be uploaded." });
        }
        const bytes = Buffer.from(input.base64, "base64");
        if (!bytes.subarray(0, 5).toString().startsWith("%PDF")) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "The uploaded file is not a valid PDF." });
        }
        if (bytes.length > MAX_PDF_SIZE_BYTES) {
          throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "PDF files must be 20 MB or smaller." });
        }

        const fileName = safeDocumentName(input.fileName);
        const storage = await storagePut(`${ctx.user.id}/study-pdfs/${Date.now()}-${fileName}`, bytes, "application/pdf");
        documentId = await db.createDocument({
          userId: ctx.user.id,
          fileName,
          storageKey: storage.key,
          storageUrl: storage.url,
          mimeType: "application/pdf",
          fileSize: bytes.length,
        });
        const pages = await extractPdfPages(bytes);
        const chunks = chunkPages(pages);
        if (!chunks.length) throw new Error("This PDF does not contain enough readable text to build a study index.");
        await db.insertDocumentChunks({ documentId, userId: ctx.user.id, chunks });
        await db.updateDocumentProcessing({ documentId, userId: ctx.user.id, status: "ready", pageCount: pages.length, chunkCount: chunks.length });
        return { id: documentId, status: "ready" as const, pageCount: pages.length, chunkCount: chunks.length };
      } catch (error) {
        if (documentId) await db.updateDocumentProcessing({ documentId, userId: ctx.user.id, status: "failed", errorMessage: error instanceof Error ? error.message : "We could not process this document." }).catch(() => undefined);
        return appError(error, "We could not process this PDF. Please try another text-based PDF.");
      }
    }),
    delete: protectedProcedure.input(z.object({ documentId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const deleted = await db.deleteDocumentForUser(input.documentId, ctx.user.id);
      if (!deleted) throw new TRPCError({ code: "NOT_FOUND", message: "This document no longer exists." });
      return { success: true };
    }),
    search: protectedProcedure.input(z.object({ query: z.string().min(2).max(300), documentIds: z.array(z.number().int().positive()).optional() })).query(async ({ ctx, input }) => {
      const results = rankChunks(await db.getChunksForSearch(ctx.user.id, input.documentIds), input.query);
      return results.map(result => ({
        documentId: result.documentId,
        documentName: result.documentName,
        pageNumber: result.pageNumber,
        chunkNumber: result.chunkNumber,
        storageUrl: result.storageUrl,
        score: Number(result.score.toFixed(3)),
        snippet: makeSnippet(result.content, input.query),
      }));
    }),
  }),

  chat: router({
    history: protectedProcedure.query(async ({ ctx }) => (await db.listChatMessages(ctx.user.id)).reverse().map(message => ({
      id: message.id,
      question: message.question,
      answer: message.answer,
      sources: JSON.parse(message.sourcesJson) as Citation[],
      createdAt: message.createdAt,
    }))),
    clear: protectedProcedure.mutation(async ({ ctx }) => {
      await db.clearChatMessages(ctx.user.id);
      return { success: true };
    }),
    ask: protectedProcedure.input(z.object({ question: z.string().min(2).max(1000), documentIds: z.array(z.number().int().positive()).optional() })).mutation(async ({ ctx, input }) => {
      try {
        const matches = rankChunks(await db.getChunksForSearch(ctx.user.id, input.documentIds), input.question);
        if (!matches.length) {
          const answer = "I couldn't find this information in the uploaded documents.";
          await db.saveChatMessage({ userId: ctx.user.id, question: input.question, answer, sourcesJson: "[]" });
          return { answer, sources: [] as Citation[] };
        }
        const sources = citationsFor(matches);
        const answer = await answerFromContext(input.question, buildContext(matches));
        await db.saveChatMessage({ userId: ctx.user.id, question: input.question, answer, sourcesJson: JSON.stringify(sources) });
        return { answer, sources };
      } catch (error) {
        return appError(error, "We could not generate an answer right now. Please try again.");
      }
    }),
  }),

  notes: router({
    list: protectedProcedure.query(({ ctx }) => db.listStudyNotes(ctx.user.id)),
    generate: protectedProcedure.input(z.object({
      documentId: z.number().int().positive(),
      kind: z.enum(["summary", "key_concepts"]),
      detail: z.enum(["short", "medium", "detailed"]).default("medium"),
    })).mutation(async ({ ctx, input }) => {
      try {
        const document = await db.getDocumentForUser(input.documentId, ctx.user.id);
        if (!document || document.status !== "ready") throw new TRPCError({ code: "NOT_FOUND", message: "Choose a processed document first." });
        const chunks = await db.getChunksForDocument(ctx.user.id, document.id);
        const context = chunks.map(chunk => `[Page ${chunk.pageNumber}] ${chunk.content}`).join("\n\n").slice(0, 18000);
        const content = await generateStudyNote({ kind: input.kind, detail: input.detail, documentName: document.fileName, context });
        const id = await db.createStudyNote({ userId: ctx.user.id, documentId: document.id, kind: input.kind, detail: input.detail, content });
        return { id, content };
      } catch (error) {
        return appError(error, "We could not generate study notes right now. Please try again.");
      }
    }),
  }),

  quizzes: router({
    list: protectedProcedure.query(({ ctx }) => db.listQuizzes(ctx.user.id)),
    get: protectedProcedure.input(z.object({ quizId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const record = await db.getQuizForUser(input.quizId, ctx.user.id);
      if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "This quiz no longer exists." });
      const questions = JSON.parse(record.quiz.questionsJson) as QuizQuestion[];
      return { id: record.quiz.id, title: record.quiz.title, documentName: record.documentName, questionCount: record.quiz.questionCount, questions: publicQuiz(questions) };
    }),
    generate: protectedProcedure.input(z.object({ documentId: z.number().int().positive(), difficulty: z.enum(["easy", "medium", "hard"]), count: z.union([z.literal(5), z.literal(10), z.literal(20)]) })).mutation(async ({ ctx, input }) => {
      try {
        const document = await db.getDocumentForUser(input.documentId, ctx.user.id);
        if (!document || document.status !== "ready") throw new TRPCError({ code: "NOT_FOUND", message: "Choose a processed document first." });
        const chunks = await db.getChunksForDocument(ctx.user.id, document.id);
        const context = chunks.map(chunk => `[Page ${chunk.pageNumber}] ${chunk.content}`).join("\n\n").slice(0, 18000);
        const questions = await generateQuestions({ documentName: document.fileName, difficulty: input.difficulty, count: input.count, context });
        const quizId = await db.createQuiz({ userId: ctx.user.id, documentId: document.id, title: `${document.fileName.replace(/\.pdf$/i, "")} review`, difficulty: input.difficulty, questionCount: input.count, questionsJson: JSON.stringify(questions) });
        return { quizId };
      } catch (error) {
        return appError(error, "We could not generate a quiz right now. Please try again.");
      }
    }),
    submit: protectedProcedure.input(z.object({ quizId: z.number().int().positive(), answers: z.array(z.number().int().min(-1).max(3)).max(20) })).mutation(async ({ ctx, input }) => {
      const record = await db.getQuizForUser(input.quizId, ctx.user.id);
      if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "This quiz no longer exists." });
      const questions = JSON.parse(record.quiz.questionsJson) as QuizQuestion[];
      if (input.answers.length !== questions.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Please answer every question before submitting." });
      const grade = gradeQuiz(questions, input.answers);
      const attemptId = await db.saveQuizAttempt({ userId: ctx.user.id, quizId: record.quiz.id, score: grade.score, totalQuestions: grade.totalQuestions, percentage: grade.percentage, answersJson: JSON.stringify(input.answers) });
      return { attemptId, ...grade };
    }),
  }),

  progress: router({
    dashboard: protectedProcedure.query(async ({ ctx }) => {
      const [documents, history, attempts, allQuizzes] = await Promise.all([
        db.listDocuments(ctx.user.id),
        db.listChatMessages(ctx.user.id),
        db.listQuizAttempts(ctx.user.id),
        db.listQuizzes(ctx.user.id),
      ]);
      const averageQuizScore = attempts.length ? Math.round(attempts.reduce((sum, attempt) => sum + attempt.percentage, 0) / attempts.length) : 0;
      return {
        metrics: { documentsUploaded: documents.length, questionsAsked: history.length, quizzesCompleted: attempts.length, averageQuizScore },
        recentDocuments: documents.slice(0, 5),
        recentAttempts: attempts.slice(0, 6),
        recentQuizzes: allQuizzes.slice(0, 4),
      };
    }),
    history: protectedProcedure.query(({ ctx }) => db.listQuizAttempts(ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;
