import { PDFParse } from "pdf-parse";
import { cleanExtractedText, type PageText } from "./retrieval";

export async function extractPdfPages(file: Buffer): Promise<PageText[]> {
  let parser: PDFParse | undefined;
  try {
    parser = new PDFParse({ data: file });
    const extracted = await parser.getText();
    const pages = extracted.pages
      .map(page => ({ pageNumber: page.num, text: cleanExtractedText(page.text) }))
      .filter(page => page.text.length > 0);

    if (pages.length === 0) {
      throw new Error("This PDF does not contain extractable text. Try a text-based PDF instead of a scanned image.");
    }
    return pages;
  } catch (error) {
    if (error instanceof Error && error.message.includes("extractable text")) throw error;
    throw new Error("We could not read this PDF. Please check that it is a valid, non-password-protected file.");
  } finally {
    await parser?.destroy().catch(() => undefined);
  }
}
