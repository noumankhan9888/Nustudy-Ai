import { describe, expect, it } from "vitest";
import { extractPdfPages } from "./pdf";
import { chunkPages, cosineSimilarity, createEmbedding } from "./retrieval";
import { answerFromContext, generateQuestions, generateStudyNote } from "./studyAi";

const SOURCE_URL = "https://lse-me314.github.io/other_resources/database_normalisation_notes.pdf";

describe("educational PDF study workflow", () => {
  it("extracts a public lecture PDF, retrieves page-aware context, and produces grounded learning material", async () => {
    const response = await fetch(SOURCE_URL);
    expect(response.ok).toBe(true);
    const pages = await extractPdfPages(Buffer.from(await response.arrayBuffer()));
    const chunks = chunkPages(pages);

    expect(pages.length).toBeGreaterThan(10);
    expect(chunks.length).toBeGreaterThan(10);
    expect(chunks.some(chunk => /normalisation/i.test(chunk.content))).toBe(true);

    const question = "What are the reasons for database normalisation?";
    const questionEmbedding = createEmbedding(question);
    const retrieved = chunks
      .map(chunk => ({ ...chunk, score: cosineSimilarity(questionEmbedding, chunk.embedding) }))
      .sort((left, right) => right.score - left.score)
      .slice(0, 4);
    const context = retrieved.map(chunk => `[Page ${chunk.pageNumber}] ${chunk.content}`).join("\n\n");

    const answer = await answerFromContext(question, context);
    const notes = await generateStudyNote({ kind: "summary", detail: "short", documentName: "Database Normalisation", context });
    const quiz = await generateQuestions({ documentName: "Database Normalisation", difficulty: "easy", count: 5, context });

    expect(answer.length).toBeGreaterThan(30);
    expect(notes.length).toBeGreaterThan(30);
    expect(quiz).toHaveLength(5);
    expect(quiz.every(item => item.options.length === 4 && item.correctIndex >= 0 && item.correctIndex <= 3)).toBe(true);
  }, 120_000);
});
