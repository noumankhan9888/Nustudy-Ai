export type PageText = {
  pageNumber: number;
  text: string;
};

export type StudyChunk = {
  pageNumber: number;
  chunkNumber: number;
  content: string;
  embedding: number[];
};

const VECTOR_DIMENSIONS = 256;
const MIN_CHUNK_CHARACTERS = 60;
const STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "it", "of", "on", "or", "that", "the", "this", "to", "was", "were", "with", "what", "which", "who", "why", "how", "when", "where", "can", "could", "should", "would", "do", "does", "did", "about", "please", "explain",
]);

export function cleanExtractedText(text: string): string {
  return text
    .replace(/\u0000/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/-\n(?=[a-z])/g, "")
    .trim();
}

function splitLongText(text: string, maxCharacters: number): string[] {
  const units = text.split(/(?<=[.!?])\s+|\n{2,}/).map(value => value.trim()).filter(Boolean);
  const chunks: string[] = [];
  let current = "";

  for (const unit of units) {
    if (!current) {
      current = unit;
      continue;
    }

    if (`${current} ${unit}`.length <= maxCharacters) {
      current = `${current} ${unit}`;
    } else {
      chunks.push(current);
      current = unit;
    }
  }

  if (current) chunks.push(current);
  return chunks;
}

/** Creates overlapping, page-aware chunks so every retrieval result can cite its original page. */
export function chunkPages(pages: PageText[], maxCharacters = 900, overlapCharacters = 160): StudyChunk[] {
  const chunks: StudyChunk[] = [];
  let chunkNumber = 1;

  for (const page of pages) {
    const cleanPage = cleanExtractedText(page.text);
    if (!cleanPage) continue;

    const units = splitLongText(cleanPage, maxCharacters);
    for (let index = 0; index < units.length; index += 1) {
      let content = units[index] ?? "";
      if (index > 0) {
        const previous = units[index - 1] ?? "";
        const tail = previous.slice(Math.max(0, previous.length - overlapCharacters));
        content = `${tail} ${content}`.trim();
      }
      if (content.length >= MIN_CHUNK_CHARACTERS) {
        chunks.push({
          pageNumber: page.pageNumber,
          chunkNumber,
          content,
          embedding: createEmbedding(content),
        });
        chunkNumber += 1;
      }
    }
  }

  return chunks;
}

function tokenize(text: string): string[] {
  return text
    .toLocaleLowerCase()
    .match(/[a-z0-9][a-z0-9'-]*/g)
    ?.filter(token => token.length > 1 && !STOP_WORDS.has(token)) ?? [];
}

function stableHash(value: string): number {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

/**
 * Builds a compact local vector embedding using signed token and bigram feature hashing.
 * It is intentionally transparent and stored with each chunk for a small, per-user index.
 */
export function createEmbedding(text: string): number[] {
  const vector = new Array<number>(VECTOR_DIMENSIONS).fill(0);
  const tokens = tokenize(text);
  const features = [...tokens, ...tokens.slice(0, -1).map((token, index) => `${token}_${tokens[index + 1]}`)];

  for (const feature of features) {
    const hash = stableHash(feature);
    const index = hash % VECTOR_DIMENSIONS;
    const sign = (hash >>> 31) === 0 ? 1 : -1;
    vector[index] += sign;
  }

  const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
  return magnitude > 0 ? vector.map(value => value / magnitude) : vector;
}

export function cosineSimilarity(left: number[], right: number[]): number {
  const size = Math.min(left.length, right.length);
  let sum = 0;
  for (let index = 0; index < size; index += 1) sum += left[index]! * right[index]!;
  return sum;
}

export function hasMeaningfulQuestionOverlap(question: string, content: string): boolean {
  const questionTerms = new Set(tokenize(question));
  if (questionTerms.size === 0) return false;
  const contentTerms = new Set(tokenize(content));
  return Array.from(questionTerms).some(term => contentTerms.has(term));
}

export function makeSnippet(content: string, query: string, maximum = 260): string {
  const queryTerms = tokenize(query);
  const lower = content.toLowerCase();
  const firstMatch = queryTerms.map(term => lower.indexOf(term)).find(position => position >= 0) ?? 0;
  const start = Math.max(0, firstMatch - 70);
  const snippet = content.slice(start, start + maximum).trim();
  return `${start > 0 ? "…" : ""}${snippet}${content.length > start + maximum ? "…" : ""}`;
}
