import { describe, expect, it } from "vitest";
import { gradeQuiz } from "./quiz";

describe("quiz scoring", () => {
  it("scores answers, computes a percentage, and retains question-level feedback", () => {
    const grade = gradeQuiz([
      { question: "What identifies a table row?", options: ["A key", "A colour", "A browser", "A cable"], correctIndex: 0, explanation: "A key identifies a row." },
      { question: "What does normalization reduce?", options: ["Latency", "Redundancy", "Brightness", "Bandwidth"], correctIndex: 1, explanation: "Normalization reduces redundant data." },
    ], [0, 3]);

    expect(grade.score).toBe(1);
    expect(grade.totalQuestions).toBe(2);
    expect(grade.percentage).toBe(50);
    expect(grade.results).toHaveLength(2);
    expect(grade.results[0]?.isCorrect).toBe(true);
    expect(grade.results[1]?.explanation).toContain("reduces redundant");
  });
});
