import { invokeLLM } from "../_core/llm";

export type Citation = {
  documentId: number;
  documentName: string;
  pageNumber: number;
  chunkNumber: number;
  storageUrl: string;
};

export type QuizQuestion = {
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
};

const MODEL = "gpt-5-mini";

function requireContent(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) throw new Error("The study AI returned an empty response. Please try again.");
  return value.trim();
}

export async function answerFromContext(question: string, context: string): Promise<string> {
  const response = await invokeLLM({
    model: MODEL,
    messages: [
      {
        role: "system",
        content: "You are Nustudy AI, a precise academic study assistant. Answer ONLY from the supplied document context. If the context does not clearly support the answer, reply exactly: \"I couldn't find this information in the uploaded documents.\" Do not use outside knowledge, do not invent facts, and do not cite pages in the prose because citations are added by the application. Keep the answer clear, well structured, and student friendly.",
      },
      { role: "user", content: `Question: ${question}\n\nDocument context:\n${context}` },
    ],
  });
  return requireContent(response.choices[0]?.message.content);
}

export async function generateStudyNote(input: {
  kind: "summary" | "key_concepts";
  detail: string;
  documentName: string;
  context: string;
}): Promise<string> {
  const goal = input.kind === "summary"
    ? `${input.detail} summary`
    : "key-concept study notes with concise definitions, relationships, and revision cues";
  const response = await invokeLLM({
    model: MODEL,
    messages: [
      { role: "system", content: "You are a careful study-note writer. Use only the provided PDF material. Write accurate Markdown with helpful headings. Never add information not supported by the document." },
      { role: "user", content: `Create a ${goal} for \"${input.documentName}\" from the following material:\n\n${input.context}` },
    ],
  });
  return requireContent(response.choices[0]?.message.content);
}

export async function generateQuestions(input: {
  documentName: string;
  difficulty: "easy" | "medium" | "hard";
  count: number;
  context: string;
}): Promise<QuizQuestion[]> {
  const response = await invokeLLM({
    model: MODEL,
    messages: [
      { role: "system", content: "Create academically fair multiple-choice questions using ONLY the supplied study material. Each question must have exactly four plausible choices, one correct answer, and a short explanation grounded in the material. Do not include trick questions or outside knowledge." },
      { role: "user", content: `Generate ${input.count} ${input.difficulty}-difficulty MCQs for \"${input.documentName}\". Document material:\n\n${input.context}` },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "study_quiz",
        strict: true,
        schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              minItems: input.count,
              maxItems: input.count,
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  options: { type: "array", minItems: 4, maxItems: 4, items: { type: "string" } },
                  correctIndex: { type: "integer", minimum: 0, maximum: 3 },
                  explanation: { type: "string" },
                },
                required: ["question", "options", "correctIndex", "explanation"],
                additionalProperties: false,
              },
            },
          },
          required: ["questions"],
          additionalProperties: false,
        },
      },
    },
  });

  const raw = requireContent(response.choices[0]?.message.content);
  const parsed = JSON.parse(raw) as { questions?: QuizQuestion[] };
  if (!Array.isArray(parsed.questions) || parsed.questions.length !== input.count) {
    throw new Error("The quiz generator returned an incomplete quiz. Please try again.");
  }
  return parsed.questions.map(question => ({
    question: question.question,
    options: [question.options[0]!, question.options[1]!, question.options[2]!, question.options[3]!],
    correctIndex: question.correctIndex,
    explanation: question.explanation,
  }));
}
