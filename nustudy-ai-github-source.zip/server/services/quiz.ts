import type { QuizQuestion } from "./studyAi";

export function gradeQuiz(questions: QuizQuestion[], answers: number[]) {
  const results = questions.map((question, index) => ({
    question: question.question,
    selectedIndex: answers[index] ?? -1,
    correctIndex: question.correctIndex,
    isCorrect: answers[index] === question.correctIndex,
    explanation: question.explanation,
  }));
  const score = results.filter(result => result.isCorrect).length;
  return {
    score,
    totalQuestions: questions.length,
    percentage: questions.length === 0 ? 0 : Math.round((score / questions.length) * 100),
    results,
  };
}
