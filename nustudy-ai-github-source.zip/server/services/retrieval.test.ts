import { describe, expect, it } from "vitest";
import { chunkPages, cosineSimilarity, createEmbedding, hasMeaningfulQuestionOverlap, makeSnippet } from "./retrieval";

describe("study retrieval pipeline", () => {
  it("creates page-aware chunks with normalized vector embeddings", () => {
    const chunks = chunkPages([{ pageNumber: 3, text: "Normalization reduces duplicate data in a relational database. It organizes data into well structured tables. A primary key identifies each row." }], 90, 20);

    expect(chunks.length).toBeGreaterThan(0);
    expect(chunks[0]?.pageNumber).toBe(3);
    expect(chunks[0]?.chunkNumber).toBe(1);
    expect(chunks[0]?.embedding).toHaveLength(256);
    const magnitude = Math.sqrt(chunks[0]!.embedding.reduce((sum, value) => sum + value * value, 0));
    expect(magnitude).toBeCloseTo(1, 5);
  });

  it("scores matching material above unrelated material", () => {
    const question = createEmbedding("What does normalization reduce in a database?");
    const matching = createEmbedding("Database normalization reduces duplicate data and organizes relations.");
    const unrelated = createEmbedding("Photosynthesis turns light energy into chemical energy in plants.");

    expect(cosineSimilarity(question, matching)).toBeGreaterThan(cosineSimilarity(question, unrelated));
    expect(hasMeaningfulQuestionOverlap("What does normalization reduce?", "Normalization reduces duplicate data.")).toBe(true);
    expect(hasMeaningfulQuestionOverlap("What does normalization reduce?", "Plants make glucose from sunlight.")).toBe(false);
  });

  it("shows a concise snippet near a matching query term", () => {
    const snippet = makeSnippet("A relational database benefits from normalization because it limits duplicate data and update anomalies.", "normalization");
    expect(snippet).toContain("normalization");
    expect(snippet.length).toBeLessThan(270);
  });
});
