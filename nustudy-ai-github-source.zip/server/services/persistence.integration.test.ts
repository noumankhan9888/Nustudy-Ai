import { afterEach, describe, expect, it } from "vitest";
import * as db from "../db";
import { gradeQuiz } from "./quiz";

const userId = 1_900_000_000 + Math.floor(Math.random() * 10_000_000);
let documentId: number | undefined;

afterEach(async () => {
  if (documentId) await db.deleteDocumentForUser(documentId, userId).catch(() => undefined);
});

describe("per-user study persistence", () => {
  it("stores a document index, saves a scored quiz attempt, and removes related records when the source is deleted", async () => {
    documentId = await db.createDocument({
      userId,
      fileName: "Database Normalisation.pdf",
      storageKey: "test/database-normalisation.pdf",
      storageUrl: "/manus-storage/test/database-normalisation.pdf",
      mimeType: "application/pdf",
      fileSize: 2048,
    });
    await db.insertDocumentChunks({
      userId,
      documentId,
      chunks: [{
        pageNumber: 2,
        chunkNumber: 1,
        content: "Normalisation removes unnecessary redundancy and reduces update anomalies.",
        embedding: [0.5, 0.5, 0, 0],
      }],
    });
    await db.updateDocumentProcessing({ documentId, userId, status: "ready", pageCount: 15, chunkCount: 1 });

    const indexed = await db.getChunksForSearch(userId, [documentId]);
    expect(indexed).toHaveLength(1);
    expect(indexed[0]).toMatchObject({ documentName: "Database Normalisation.pdf", pageNumber: 2, chunkNumber: 1 });

    const questions = [{
      question: "What does normalisation reduce?",
      options: ["Redundancy", "Screen brightness", "Network cables", "Battery life"] as [string, string, string, string],
      correctIndex: 0,
      explanation: "Normalisation reduces redundant data.",
    }];
    const quizId = await db.createQuiz({
      userId,
      documentId,
      title: "Database Normalisation review",
      difficulty: "easy",
      questionCount: 1,
      questionsJson: JSON.stringify(questions),
    });
    const grade = gradeQuiz(questions, [0]);
    await db.saveQuizAttempt({ userId, quizId, score: grade.score, totalQuestions: grade.totalQuestions, percentage: grade.percentage, answersJson: JSON.stringify([0]) });
    expect(await db.listQuizAttempts(userId)).toHaveLength(1);

    expect(await db.deleteDocumentForUser(documentId, userId)).toBe(true);
    expect(await db.getDocumentForUser(documentId, userId)).toBeUndefined();
    expect(await db.getChunksForSearch(userId, [documentId])).toHaveLength(0);
    expect(await db.listQuizAttempts(userId)).toHaveLength(0);
    documentId = undefined;
  });
});
