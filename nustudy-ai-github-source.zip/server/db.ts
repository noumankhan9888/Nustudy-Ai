import { and, desc, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  chatMessages,
  documentChunks,
  documents,
  quizAttempts,
  quizzes,
  studyNotes,
  type Document,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("The study database is not available right now.");
  return db;
}

function getInsertedId(result: unknown): number {
  const header = Array.isArray(result) ? result[0] : result;
  const id = Number((header as { insertId?: unknown } | undefined)?.insertId);
  if (!Number.isInteger(id) || id <= 0) throw new Error("The database did not return a valid record identifier.");
  return id;
}

export async function upsertUser(user: { openId: string; name?: string | null; email?: string | null; loginMethod?: string | null; role?: "user" | "admin"; lastSignedIn?: Date }) {
  const db = await requireDb();
  const values = {
    openId: user.openId,
    name: user.name ?? null,
    email: user.email ?? null,
    loginMethod: user.loginMethod ?? null,
    role: user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : "user"),
    lastSignedIn: user.lastSignedIn ?? new Date(),
  } as const;
  await db.insert((await import("../drizzle/schema")).users).values(values).onDuplicateKeyUpdate({ set: values });
}

export async function getUserByOpenId(openId: string) {
  const db = await requireDb();
  const { users } = await import("../drizzle/schema");
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function createDocument(input: {
  userId: number;
  fileName: string;
  storageKey: string;
  storageUrl: string;
  mimeType: string;
  fileSize: number;
}): Promise<number> {
  const db = await requireDb();
  const result = await db.insert(documents).values({ ...input, status: "processing" });
  return getInsertedId(result);
}

export async function updateDocumentProcessing(input: { documentId: number; userId: number; status: "ready" | "failed"; pageCount?: number; chunkCount?: number; errorMessage?: string | null }) {
  const db = await requireDb();
  await db.update(documents).set({
    status: input.status,
    pageCount: input.pageCount,
    chunkCount: input.chunkCount,
    errorMessage: input.errorMessage ?? null,
  }).where(and(eq(documents.id, input.documentId), eq(documents.userId, input.userId)));
}

export async function insertDocumentChunks(input: { documentId: number; userId: number; chunks: Array<{ pageNumber: number; chunkNumber: number; content: string; embedding: number[] }> }) {
  const db = await requireDb();
  if (!input.chunks.length) return;
  await db.insert(documentChunks).values(input.chunks.map(chunk => ({
    documentId: input.documentId,
    userId: input.userId,
    pageNumber: chunk.pageNumber,
    chunkNumber: chunk.chunkNumber,
    content: chunk.content,
    embeddingJson: JSON.stringify(chunk.embedding),
  })));
}

export async function listDocuments(userId: number) {
  const db = await requireDb();
  return db.select().from(documents).where(eq(documents.userId, userId)).orderBy(desc(documents.createdAt));
}

export async function getDocumentForUser(documentId: number, userId: number): Promise<Document | undefined> {
  const db = await requireDb();
  const rows = await db.select().from(documents).where(and(eq(documents.id, documentId), eq(documents.userId, userId))).limit(1);
  return rows[0];
}

export async function getChunksForDocument(userId: number, documentId: number) {
  const db = await requireDb();
  return db.select().from(documentChunks).where(and(eq(documentChunks.userId, userId), eq(documentChunks.documentId, documentId))).orderBy(documentChunks.pageNumber, documentChunks.chunkNumber);
}

export async function getChunksForSearch(userId: number, documentIds?: number[]) {
  const db = await requireDb();
  const filters = [eq(documentChunks.userId, userId)];
  if (documentIds && documentIds.length > 0) filters.push(inArray(documentChunks.documentId, documentIds));
  return db.select({
    id: documentChunks.id,
    documentId: documentChunks.documentId,
    pageNumber: documentChunks.pageNumber,
    chunkNumber: documentChunks.chunkNumber,
    content: documentChunks.content,
    embeddingJson: documentChunks.embeddingJson,
    documentName: documents.fileName,
    storageUrl: documents.storageUrl,
  }).from(documentChunks).innerJoin(documents, eq(documentChunks.documentId, documents.id)).where(and(...filters)).limit(3000);
}

export async function deleteDocumentForUser(documentId: number, userId: number): Promise<boolean> {
  const db = await requireDb();
  const document = await getDocumentForUser(documentId, userId);
  if (!document) return false;
  const ownedQuizzes = await db.select({ id: quizzes.id }).from(quizzes).where(and(eq(quizzes.userId, userId), eq(quizzes.documentId, documentId)));
  const quizIds = ownedQuizzes.map(quiz => quiz.id);
  if (quizIds.length) await db.delete(quizAttempts).where(and(eq(quizAttempts.userId, userId), inArray(quizAttempts.quizId, quizIds)));
  await db.delete(studyNotes).where(and(eq(studyNotes.userId, userId), eq(studyNotes.documentId, documentId)));
  await db.delete(quizzes).where(and(eq(quizzes.userId, userId), eq(quizzes.documentId, documentId)));
  await db.delete(documentChunks).where(and(eq(documentChunks.userId, userId), eq(documentChunks.documentId, documentId)));
  await db.delete(documents).where(and(eq(documents.userId, userId), eq(documents.id, documentId)));
  return true;
}

export async function saveChatMessage(input: { userId: number; question: string; answer: string; sourcesJson: string }) {
  const db = await requireDb();
  await db.insert(chatMessages).values(input);
}

export async function listChatMessages(userId: number) {
  const db = await requireDb();
  return db.select().from(chatMessages).where(eq(chatMessages.userId, userId)).orderBy(desc(chatMessages.createdAt)).limit(40);
}

export async function clearChatMessages(userId: number) {
  const db = await requireDb();
  await db.delete(chatMessages).where(eq(chatMessages.userId, userId));
}

export async function createStudyNote(input: { userId: number; documentId: number; kind: "summary" | "key_concepts"; detail: string; content: string }): Promise<number> {
  const db = await requireDb();
  const result = await db.insert(studyNotes).values(input);
  return getInsertedId(result);
}

export async function listStudyNotes(userId: number) {
  const db = await requireDb();
  return db.select({
    id: studyNotes.id,
    documentId: studyNotes.documentId,
    kind: studyNotes.kind,
    detail: studyNotes.detail,
    content: studyNotes.content,
    createdAt: studyNotes.createdAt,
    documentName: documents.fileName,
  }).from(studyNotes).innerJoin(documents, eq(studyNotes.documentId, documents.id)).where(eq(studyNotes.userId, userId)).orderBy(desc(studyNotes.createdAt));
}

export async function createQuiz(input: { userId: number; documentId: number; title: string; difficulty: "easy" | "medium" | "hard"; questionCount: number; questionsJson: string }): Promise<number> {
  const db = await requireDb();
  const result = await db.insert(quizzes).values(input);
  return getInsertedId(result);
}

export async function listQuizzes(userId: number) {
  const db = await requireDb();
  return db.select({
    id: quizzes.id,
    documentId: quizzes.documentId,
    title: quizzes.title,
    difficulty: quizzes.difficulty,
    questionCount: quizzes.questionCount,
    createdAt: quizzes.createdAt,
    documentName: documents.fileName,
  }).from(quizzes).innerJoin(documents, eq(quizzes.documentId, documents.id)).where(eq(quizzes.userId, userId)).orderBy(desc(quizzes.createdAt));
}

export async function getQuizForUser(quizId: number, userId: number) {
  const db = await requireDb();
  const rows = await db.select({ quiz: quizzes, documentName: documents.fileName }).from(quizzes).innerJoin(documents, eq(quizzes.documentId, documents.id)).where(and(eq(quizzes.id, quizId), eq(quizzes.userId, userId))).limit(1);
  return rows[0];
}

export async function saveQuizAttempt(input: { userId: number; quizId: number; score: number; totalQuestions: number; percentage: number; answersJson: string }): Promise<number> {
  const db = await requireDb();
  const result = await db.insert(quizAttempts).values(input);
  return getInsertedId(result);
}

export async function listQuizAttempts(userId: number) {
  const db = await requireDb();
  return db.select({
    id: quizAttempts.id,
    score: quizAttempts.score,
    totalQuestions: quizAttempts.totalQuestions,
    percentage: quizAttempts.percentage,
    createdAt: quizAttempts.createdAt,
    quizTitle: quizzes.title,
    documentName: documents.fileName,
  }).from(quizAttempts).innerJoin(quizzes, eq(quizAttempts.quizId, quizzes.id)).innerJoin(documents, eq(quizzes.documentId, documents.id)).where(eq(quizAttempts.userId, userId)).orderBy(desc(quizAttempts.createdAt));
}
