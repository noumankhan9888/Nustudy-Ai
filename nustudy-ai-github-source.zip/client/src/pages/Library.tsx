import { useRef, useState } from "react";
import { AlertCircle, CheckCircle2, FileText, Loader2, Search, Trash2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { StudyPageHeader } from "@/components/StudyPageHeader";
import { LoadError } from "@/components/LoadError";
import { formatDate, formatFileSize } from "@/lib/study";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

async function fileAsBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("We could not read that file."));
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.readAsDataURL(file);
  });
}

export default function Library() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [search, setSearch] = useState("");
  const utils = trpc.useUtils();
  const { data: documents, isLoading, isError: documentsFailed } = trpc.documents.list.useQuery();
  const upload = trpc.documents.upload.useMutation({ onSuccess: result => { toast.success(`Processed ${result.pageCount} pages into ${result.chunkCount} study chunks.`); void utils.documents.list.invalidate(); void utils.progress.dashboard.invalidate(); }, onError: error => toast.error(error.message) });
  const remove = trpc.documents.delete.useMutation({ onSuccess: () => { toast.success("Document removed from your study library."); void utils.documents.list.invalidate(); void utils.progress.dashboard.invalidate(); }, onError: error => toast.error(error.message) });
  const searchResults = trpc.documents.search.useQuery({ query: search }, { enabled: search.trim().length >= 2 });

  const processFiles = async (files: FileList | File[]) => {
    const file = Array.from(files)[0];
    if (!file) return;
    if (file.type !== "application/pdf" || !file.name.toLowerCase().endsWith(".pdf")) return toast.error("Please choose a PDF file.");
    if (file.size > 20 * 1024 * 1024) return toast.error("This PDF is larger than the 20 MB study-library limit.");
    try { upload.mutate({ fileName: file.name, mimeType: file.type, base64: await fileAsBase64(file) }); } catch (error) { toast.error(error instanceof Error ? error.message : "The file could not be prepared."); }
  };

  return <div className="study-page space-y-8"><StudyPageHeader eyebrow="My documents" title="Drop your study materials here." description="Upload PDF notes, lectures, or study material and start learning with AI. Every source stays private to your study library." action={<Button onClick={() => inputRef.current?.click()} className="gap-2 rounded-xl bg-indigo-600 shadow-[0_8px_20px_rgba(79,70,229,0.16)] hover:bg-indigo-700"><UploadCloud className="h-4 w-4" /> Upload PDF</Button>} />
    <input ref={inputRef} type="file" accept="application/pdf" className="hidden" onChange={event => { if (event.target.files) void processFiles(event.target.files); event.currentTarget.value = ""; }} />
    <Card className={`rounded-2xl border-2 border-dashed shadow-none ${dragging ? "border-indigo-400 bg-indigo-50" : "border-indigo-100 bg-white"}`}><CardContent onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); void processFiles(event.dataTransfer.files); }} className="flex min-h-56 flex-col items-center justify-center p-6 text-center"><div className="rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-500 p-3 text-white shadow-[0_8px_18px_rgba(79,70,229,0.20)]"><UploadCloud className="h-6 w-6" /></div><h2 className="mt-4 text-lg font-bold text-slate-900">{upload.isPending ? "Preparing your study source…" : "Drop your study materials here"}</h2><p className="mt-1 max-w-md text-sm leading-6 text-slate-500">{upload.isPending ? "Uploading securely, extracting page text, then building your study index." : "Upload PDF notes, lectures or study material and start learning with AI."}</p>{!upload.isPending && <Button onClick={() => inputRef.current?.click()} className="mt-5 rounded-xl bg-indigo-600 hover:bg-indigo-700">Upload PDF</Button>}{upload.isPending && <div className="mt-5 flex items-center gap-2 text-sm font-semibold text-indigo-700"><Loader2 className="h-4 w-4 animate-spin" /> Uploading · extracting text · indexing</div>}</CardContent></Card>

    <section className="space-y-4"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><h2 className="text-lg font-semibold tracking-[-0.02em] text-slate-900">Your documents</h2><p className="mt-1 text-sm text-slate-500">Manage the sources used by your personal study assistant.</p></div><div className="relative w-full sm:w-72"><Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" /><Input value={search} onChange={event => setSearch(event.target.value)} className="rounded-xl border-slate-200 bg-white pl-9" placeholder="Search your material" /></div></div>{documentsFailed && <LoadError message="We could not load your document library. Please refresh and try again." />}
      {search.trim().length >= 2 ? <SearchResults results={searchResults.data ?? []} loading={searchResults.isLoading} /> : <div className="grid gap-3">{isLoading ? <div className="rounded-xl border border-slate-200 bg-white p-6 text-sm text-slate-500">Loading your study library…</div> : documents?.length ? documents.map(document => <Card key={document.id} className="student-card"><CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center"><div className="self-start rounded-xl bg-rose-50 p-3 text-rose-600"><FileText className="h-5 w-5" /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h3 className="truncate text-sm font-bold text-slate-900">{document.fileName}</h3><Status status={document.status} /></div><p className="mt-1 text-xs text-slate-500">Uploaded {formatDate(document.createdAt)} · {formatFileSize(document.fileSize)} · {document.pageCount} pages · {document.chunkCount} chunks</p>{document.status === "failed" && <p className="mt-2 inline-flex items-center gap-1 text-xs text-rose-600"><AlertCircle className="h-3.5 w-3.5" /> {document.errorMessage ?? "We could not process this file."}</p>}</div><div className="flex items-center gap-2"><Link href={`/ask?document=${document.id}`}><Button disabled={document.status !== "ready"} variant="outline" className="rounded-xl border-indigo-200 bg-white text-indigo-700 hover:bg-indigo-50">Chat</Button></Link><Button disabled={remove.isPending} onClick={() => { if (window.confirm(`Remove ${document.fileName} and all associated study records?`)) remove.mutate({ documentId: document.id }); }} size="icon" variant="ghost" className="rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label={`Delete ${document.fileName}`}><Trash2 className="h-4 w-4" /></Button></div></CardContent></Card>) : <EmptyLibrary />}</div>}</section>
  </div>;
}

function Status({ status }: { status: "uploaded" | "processing" | "ready" | "failed" }) { const ready = status === "ready"; return <Badge variant="secondary" className={ready ? "bg-emerald-50 text-emerald-700" : status === "failed" ? "bg-rose-50 text-rose-700" : "bg-amber-50 text-amber-700"}>{ready && <CheckCircle2 className="mr-1 h-3 w-3" />}{status}</Badge>; }
function EmptyLibrary() { return <div className="rounded-2xl border border-dashed border-slate-200 bg-white px-6 py-14 text-center"><div className="mx-auto w-fit rounded-xl bg-slate-100 p-3 text-slate-500"><FileText className="h-5 w-5" /></div><h3 className="mt-3 text-sm font-semibold text-slate-800">No sources yet</h3><p className="mt-1 text-sm text-slate-500">Upload a PDF above, then turn it into answers, notes, and practice questions.</p></div>; }
function SearchResults({ results, loading }: { results: Array<{ documentId: number; documentName: string; pageNumber: number; chunkNumber: number; storageUrl: string; score: number; snippet: string }>; loading: boolean }) { return <div className="space-y-2">{loading ? <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">Searching your indexed material…</p> : results.length ? results.map(result => <a key={`${result.documentId}-${result.chunkNumber}`} href={result.storageUrl} target="_blank" rel="noreferrer" className="block rounded-xl border border-slate-200 bg-white p-4 transition-colors hover:border-indigo-200 hover:bg-indigo-50/30"><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-slate-800">{result.documentName}</p><Badge variant="secondary" className="bg-indigo-50 text-indigo-700">Page {result.pageNumber}</Badge></div><p className="mt-2 text-sm leading-6 text-slate-600">{result.snippet}</p></a>) : <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">No matching indexed passage was found.</p>}</div>; }
