import { Link } from "wouter";
import { ArrowUpRight, BookOpen, CircleHelp, ClipboardCheck, FileText, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StudyPageHeader } from "@/components/StudyPageHeader";
import { LoadError } from "@/components/LoadError";
import { formatDate, formatFileSize, percentageLabel } from "@/lib/study";
import { trpc } from "@/lib/trpc";

const metricCards = [
  { key: "documentsUploaded", label: "Documents", icon: FileText, tone: "bg-indigo-50 text-indigo-600" },
  { key: "questionsAsked", label: "Questions asked", icon: CircleHelp, tone: "bg-violet-50 text-violet-600" },
  { key: "quizzesCompleted", label: "Quizzes completed", icon: ClipboardCheck, tone: "bg-emerald-50 text-emerald-600" },
  { key: "averageQuizScore", label: "Average score", icon: Sparkles, tone: "bg-amber-50 text-amber-600", suffix: "%" },
] as const;

export default function Dashboard() {
  const { data, isLoading, isError } = trpc.progress.dashboard.useQuery();
  const metrics = data?.metrics;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="study-page space-y-8">
      <StudyPageHeader eyebrow="Your learning dashboard" title={`${greeting} 👋`} description="Ready to learn something new today? Keep your sources, questions, notes, and quiz performance in one focused workspace." action={<Link href="/library"><Button className="gap-2 rounded-xl bg-indigo-600 px-4 shadow-[0_8px_20px_rgba(79,70,229,0.18)] hover:bg-indigo-700"><BookOpen className="h-4 w-4" /> Upload PDF</Button></Link>} />

      {isError && <LoadError message="We could not load your latest study metrics. Your documents and progress are safe; please refresh to try again." />}
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {metricCards.map(card => {
          const Icon = card.icon;
          const value = metrics?.[card.key] ?? 0;
          const suffix = "suffix" in card ? card.suffix : "";
          return <Card key={card.key} className="student-card"><CardContent className="p-5"><div className="flex items-start justify-between"><div><p className="text-sm font-medium text-slate-500">{card.label}</p><p className="mt-2 text-3xl font-bold tracking-[-0.04em] text-slate-900">{isLoading ? "—" : `${value}${suffix}`}</p></div><div className={`rounded-xl p-2.5 ${card.tone}`}><Icon className="h-4 w-4" /></div></div></CardContent></Card>;
        })}
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="student-card overflow-hidden"><CardContent className="p-0"><div className="flex items-center justify-between border-b border-slate-100 px-6 py-5"><div><h2 className="text-base font-bold text-slate-900">Recent documents</h2><p className="mt-1 text-sm text-slate-500">Your uploaded material is ready for focused study.</p></div><Link href="/library" className="inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 hover:text-indigo-700">My documents <ArrowUpRight className="h-4 w-4" /></Link></div>
            {data?.recentDocuments.length ? <div className="divide-y divide-slate-100">{data.recentDocuments.map(document => <div key={document.id} className="flex items-center gap-3 px-6 py-4"><div className="rounded-xl bg-rose-50 p-2.5 text-rose-600"><FileText className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-slate-800">{document.fileName}</p><p className="mt-0.5 text-xs text-slate-500">{document.pageCount} pages · {document.chunkCount} indexed · {formatFileSize(document.fileSize)}</p></div><Badge variant="secondary" className={document.status === "ready" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}>{document.status}</Badge></div>)}</div> : <EmptyPanel icon={<FileText className="h-5 w-5" />} title="Your library is waiting" body="Upload a text-based PDF to begin building your personal study space." href="/library" label="Upload a PDF" />}</CardContent></Card>

        <Card className="border-slate-200/70 bg-gradient-to-br from-indigo-600 to-violet-700 text-white shadow-[0_14px_35px_rgba(79,70,229,0.24)]"><CardContent className="flex h-full min-h-[260px] flex-col justify-between p-6"><div><div className="inline-flex rounded-xl bg-white/15 p-2.5"><Sparkles className="h-5 w-5" /></div><h2 className="mt-5 text-xl font-semibold tracking-[-0.03em]">Make your next review more active.</h2><p className="mt-2 text-sm leading-6 text-indigo-100">Ask one focused question or turn a source into a short quiz while the topic is fresh.</p></div><div className="flex gap-2"><Link href="/ask" className="flex-1"><Button variant="secondary" className="w-full rounded-xl bg-white text-indigo-700 hover:bg-indigo-50">Ask your PDFs</Button></Link><Link href="/quizzes"><Button variant="outline" className="rounded-xl border-white/30 bg-white/10 text-white hover:bg-white/20 hover:text-white">Quiz</Button></Link></div></CardContent></Card>
      </section>

      <section className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <Card className="border-slate-200/70 shadow-[0_2px_14px_rgba(15,23,42,0.035)]"><CardContent className="p-6"><div className="flex items-center justify-between"><div><h2 className="text-base font-semibold text-slate-900">Latest quiz outcome</h2><p className="mt-1 text-sm text-slate-500">A gentle view of your recent recall practice.</p></div><Link href="/progress" className="text-sm font-semibold text-indigo-600">Progress</Link></div>{data?.recentAttempts[0] ? <div className="mt-7 flex items-end justify-between"><div><p className="text-4xl font-semibold tracking-[-0.05em] text-slate-950">{data.recentAttempts[0].percentage}%</p><p className="mt-1 text-sm font-medium text-slate-600">{percentageLabel(data.recentAttempts[0].percentage)}</p><p className="mt-3 text-xs text-slate-400">{data.recentAttempts[0].quizTitle} · {formatDate(data.recentAttempts[0].createdAt)}</p></div><div className="flex h-20 w-20 items-center justify-center rounded-full border-[9px] border-indigo-100 text-sm font-bold text-indigo-600">{data.recentAttempts[0].score}/{data.recentAttempts[0].totalQuestions}</div></div> : <div className="mt-7 rounded-xl bg-slate-50 p-4 text-sm leading-6 text-slate-500">No completed quiz yet. Generate a short quiz when you are ready to check understanding.</div>}</CardContent></Card>
        <Card className="border-slate-200/70 shadow-[0_2px_14px_rgba(15,23,42,0.035)]"><CardContent className="p-6"><div className="flex items-center justify-between"><div><h2 className="text-base font-semibold text-slate-900">Quick study actions</h2><p className="mt-1 text-sm text-slate-500">Choose the next useful step in your revision session.</p></div></div><div className="mt-5 grid gap-3 sm:grid-cols-3"><QuickAction href="/ask" icon={<CircleHelp className="h-4 w-4" />} title="Ask" body="Get a cited answer" /><QuickAction href="/summaries" icon={<Sparkles className="h-4 w-4" />} title="Summarize" body="Create revision notes" /><QuickAction href="/quizzes" icon={<ClipboardCheck className="h-4 w-4" />} title="Practice" body="Test your recall" /></div></CardContent></Card>
      </section>
    </div>
  );
}

function EmptyPanel({ icon, title, body, href, label }: { icon: React.ReactNode; title: string; body: string; href: string; label: string }) {
  return <div className="flex flex-col items-center px-6 py-12 text-center"><div className="rounded-xl bg-slate-100 p-3 text-slate-500">{icon}</div><h3 className="mt-3 text-sm font-semibold text-slate-800">{title}</h3><p className="mt-1 max-w-sm text-sm leading-6 text-slate-500">{body}</p><Link href={href}><Button variant="outline" className="mt-4 rounded-xl">{label}</Button></Link></div>;
}

function QuickAction({ href, icon, title, body }: { href: string; icon: React.ReactNode; title: string; body: string }) {
  return <Link href={href} className="rounded-xl border border-slate-200 p-4 transition-all hover:-translate-y-0.5 hover:border-indigo-200 hover:bg-indigo-50/40"><div className="text-indigo-600">{icon}</div><p className="mt-3 text-sm font-semibold text-slate-800">{title}</p><p className="mt-1 text-xs text-slate-500">{body}</p></Link>;
}
