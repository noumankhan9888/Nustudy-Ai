import { AlertCircle } from "lucide-react";

export function LoadError({ message = "We could not load this study data. Please refresh and try again." }: { message?: string }) {
  return <div role="alert" className="flex items-start gap-3 rounded-xl border border-rose-100 bg-rose-50 px-4 py-3 text-sm text-rose-800"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><p className="leading-6">{message}</p></div>;
}
