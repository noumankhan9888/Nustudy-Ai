import { Fragment } from "react";

function inlineText(value: string) {
  const segments = value.split(/(\*\*.*?\*\*|`.*?`)/g);
  return segments.map((segment, index) => {
    if (segment.startsWith("**") && segment.endsWith("**")) return <strong key={index} className="font-semibold text-slate-900">{segment.slice(2, -2)}</strong>;
    if (segment.startsWith("`") && segment.endsWith("`")) return <code key={index} className="rounded bg-slate-100 px-1 py-0.5 text-[0.88em] text-indigo-700">{segment.slice(1, -1)}</code>;
    return <Fragment key={index}>{segment}</Fragment>;
  });
}

/** A deliberately small Markdown subset for AI answers, summaries, and revision notes. */
export function StudyMarkdown({ content }: { content: string }) {
  const lines = content.replace(/\r/g, "").split("\n");
  const blocks: React.ReactNode[] = [];
  let bullets: string[] = [];
  const flushBullets = () => {
    if (!bullets.length) return;
    blocks.push(<ul key={`list-${blocks.length}`} className="my-3 list-disc space-y-1.5 pl-5 text-sm leading-6 text-slate-700">{bullets.map((item, index) => <li key={index}>{inlineText(item)}</li>)}</ul>);
    bullets = [];
  };

  for (const line of lines) {
    const value = line.trim();
    if (!value) { flushBullets(); continue; }
    if (/^[-*]\s+/.test(value)) { bullets.push(value.replace(/^[-*]\s+/, "")); continue; }
    flushBullets();
    if (/^###\s+/.test(value)) blocks.push(<h3 key={`h3-${blocks.length}`} className="mt-5 text-sm font-semibold text-slate-900">{inlineText(value.replace(/^###\s+/, ""))}</h3>);
    else if (/^##\s+/.test(value)) blocks.push(<h2 key={`h2-${blocks.length}`} className="mt-6 text-lg font-semibold tracking-[-0.02em] text-slate-900">{inlineText(value.replace(/^##\s+/, ""))}</h2>);
    else if (/^#\s+/.test(value)) blocks.push(<h1 key={`h1-${blocks.length}`} className="mt-6 text-xl font-semibold tracking-[-0.03em] text-slate-900">{inlineText(value.replace(/^#\s+/, ""))}</h1>);
    else blocks.push(<p key={`p-${blocks.length}`} className="my-2 text-sm leading-7 text-slate-700">{inlineText(value)}</p>);
  }
  flushBullets();
  return <>{blocks}</>;
}
