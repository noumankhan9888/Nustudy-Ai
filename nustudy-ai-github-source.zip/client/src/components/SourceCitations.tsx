import { FileText, ExternalLink } from "lucide-react";

export type SourceCitation = {
  documentId: number;
  documentName: string;
  pageNumber: number;
  chunkNumber: number;
  storageUrl: string;
};

export function SourceCitations({ sources }: { sources: SourceCitation[] }) {
  if (!sources.length) return null;
  return (
    <div className="mt-4 border-t border-indigo-100 pt-3">
      <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-indigo-500">Sources</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {sources.map((source, index) => (
          <a key={`${source.documentId}-${source.chunkNumber}-${index}`} href={source.storageUrl} target="_blank" rel="noreferrer" className="group inline-flex max-w-full items-center gap-1.5 rounded-lg border border-indigo-100 bg-indigo-50 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-100">
            <FileText className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">{source.documentName} · p. {source.pageNumber}</span>
            <ExternalLink className="h-3 w-3 shrink-0 opacity-60" />
          </a>
        ))}
      </div>
    </div>
  );
}
