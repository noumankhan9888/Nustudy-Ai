import type { ReactNode } from "react";

export function StudyPageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return (
    <header className="flex flex-col gap-4 border-b border-slate-200 pb-7 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        <p className="study-eyebrow">{eyebrow}</p>
        <h1 className="mt-2.5 text-3xl font-bold tracking-[-0.045em] text-slate-900 sm:text-[2rem]">{title}</h1>
        <p className="mt-2.5 text-sm leading-6 text-slate-500">{description}</p>
      </div>
      {action}
    </header>
  );
}
